<template>
  <div>
    <h1>Statistiques de la plateforme</h1>
    <ul>Contenu de la page de statistiques (Aucunement eu le temps de le faire).</ul>
    <ul>Normalement, seulement disponible en tant qu'Admin mais l'OIDC ne fonctione pas.</ul>
  </div>
</template>
    
<script>


  export default {
    name: 'CompStatistiques',
  };
</script>
    