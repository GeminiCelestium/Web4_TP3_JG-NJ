<template>
  <Details />
</template>
  
<script>
  import Details from '@/components/CompDetailsEvenement.vue'
  
  export default {
    name: 'VueDetails',
    components: {
        Details
    }
  }
</script>