<template>
  <Participation />
</template>
  
<script>
  import Participation from '@/components/CompParticiperEvenement.vue'
  
  export default {
    name: 'VueParticiperEvenement',
    components: {
        Participation
    }
  }
</script>