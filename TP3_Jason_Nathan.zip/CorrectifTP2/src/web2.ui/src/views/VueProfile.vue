<template>
  <Profile />
</template>

<script>
  import Profile from '@/components/CompProfile.vue'

  export default {
    name: 'VueProfile',
    components: {
      Profile
    },
    methods: {
    
    },
  }
</script>