<template>
  <Stats />
</template>

<script>
  import Stats from '@/components/CompStatistiques.vue'

  export default {
    name: 'VueStatistiques',
    components: {
      Stats
    }
  }
</script>