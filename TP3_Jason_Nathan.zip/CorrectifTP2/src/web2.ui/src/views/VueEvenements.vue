<template>
  <div class="events">
    <router-view></router-view>
  </div>
</template>
  
<script>
  export default {
    name: 'VueEvenements',
  };
</script>
  